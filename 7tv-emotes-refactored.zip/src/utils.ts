interface OnDemandPictureOptions {
	name: string;
	cachePath: string;
	cdnUrl: string;
	preferCache: boolean;
}

export function formatBytes(bytes: number): string {
	if (bytes === 0) {
		return '0 Bytes';
	}
	const unit = 1024;
	const sizes = ['Bytes', 'KB', 'MB', 'GB'];
	const index = Math.floor(Math.log(bytes) / Math.log(unit));
	return `${parseFloat((bytes / Math.pow(unit, index)).toFixed(2))} ${sizes[index]}`;
}

export function createNoCacheEmoteElement(name: string, id: string): HTMLElement {
	const span = document.createElement('span');
	span.className = 'seven-tv-emote';
	span.setAttribute('title', `:${name}:`);

	const img = document.createElement('img');
	img.setAttribute('src', `https://cdn.7tv.app/emote/${id}/1x.webp`);
	img.setAttribute('alt', name);
	img.className = 'seven-tv-inline-emote';

	span.appendChild(img);
	return span;
}

export function createOnDemandEmotePicture(options: OnDemandPictureOptions): HTMLElement {
	const picture = document.createElement('picture');
	picture.className = 'seven-tv-emote';

	const cacheSource = document.createElement('source');
	cacheSource.setAttribute('srcset', options.cachePath);
	cacheSource.setAttribute('type', 'image/webp');

	const cdnSource = document.createElement('source');
	cdnSource.setAttribute('srcset', options.cdnUrl);
	cdnSource.setAttribute('type', 'image/webp');

	if (options.preferCache) {
		picture.appendChild(cacheSource);
		picture.appendChild(cdnSource);
	} else {
		picture.appendChild(cdnSource);
		picture.appendChild(cacheSource);
	}

	const img = document.createElement('img');
	img.setAttribute('src', options.preferCache ? options.cachePath : options.cdnUrl);
	img.setAttribute('alt', `:${options.name}:`);
	img.setAttribute('title', `:${options.name}:`);
	img.className = 'seven-tv-inline-emote';

	picture.appendChild(img);
	return picture;
}
