import { PluginLogger } from './logger';

export async function fetchEmotesForTwitchId(
	twitchId: string,
	logger: PluginLogger
): Promise<Map<string, string>> {
	const emoteMap = new Map<string, string>();

	try {
		logger.log(`Fetching 7TV emotes for Twitch ID: ${twitchId}`, 'debug');

		const userRes = await fetch(`https://7tv.io/v3/users/twitch/${encodeURIComponent(twitchId)}`);
		if (!userRes.ok) {
			throw new Error(`HTTP ${userRes.status}`);
		}
		const userData = await userRes.json();

		const emoteSetId = userData?.emote_set?.id ||
			(userData?.emote_sets && userData.emote_sets[0]?.id);
		if (!emoteSetId) {
			throw new Error('No emote set found');
		}

		logger.log(`Found emote set ID: ${emoteSetId}`, 'debug');

		const setRes = await fetch(`https://7tv.io/v3/emote-sets/${encodeURIComponent(emoteSetId)}`);
		if (!setRes.ok) {
			throw new Error(`HTTP ${setRes.status}`);
		}
		const setData = await setRes.json();

		if (Array.isArray(setData?.emotes)) {
			for (const emote of setData.emotes) {
				if (emote?.name && emote?.id) {
					emoteMap.set(emote.name, emote.id);
				}
			}
			logger.log(`Mapped ${emoteMap.size} emotes`, 'debug');
		}
	} catch (error) {
		logger.error(`Failed to fetch 7TV emotes: ${error}`);
	}

	return emoteMap;
}
