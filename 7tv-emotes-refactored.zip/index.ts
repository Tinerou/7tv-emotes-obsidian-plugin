import { Editor, Notice, Plugin } from 'obsidian';
import { fetchEmotesForTwitchId } from './src/api';
import { DownloadProgressTracker } from './src/DownloadProgressTracker';
import { EmoteSuggest } from './src/EmoteSuggest';
import { PluginLogger } from './src/logger';
import { SettingsTab } from './src/SettingsTab';
import {
	createNoCacheEmoteElement,
	createOnDemandEmotePicture
} from './src/utils';
import {
	DEFAULT_SETTINGS,
	LogLevel,
	SevenTVSettings,
	StreamerDefinition
} from './src/types';

export default class SevenTVPlugin extends Plugin {
	settings: SevenTVSettings = DEFAULT_SETTINGS;

	private readonly CACHE_DIR = '_7tv-emotes-cache';
	private emoteSuggest!: EmoteSuggest;
	private logger!: PluginLogger;
	private downloadTracker!: DownloadProgressTracker;
	private activeDownloadPromise: Promise<void> | null = null;
	private preCacheComplete = false;
	private abortController: AbortController | null = null;
	private readonly stateListeners = new Set<() => void>();

	async onload(): Promise<void> {
		await this.loadSettings();
		this.logger = new PluginLogger(() => this.settings.logLevel);
		this.downloadTracker = new DownloadProgressTracker(this, () => this.notifyStateChange());

		this.register(() => this.downloadTracker.cleanup());
		this.register(() => this.abortController?.abort());

		if (!this.settings.builtInStreamers.length) {
			const streamers = await this.loadStreamersFromJson();
			if (streamers.length) {
				this.settings.builtInStreamers = streamers;
				await this.saveSettings();
			}
		}

		await this.ensureCacheInitialized();

		this.emoteSuggest = new EmoteSuggest(this.app, this);
		this.registerEditorSuggest(this.emoteSuggest);

		const activeId = this.getActiveTwitchId();
		if (activeId) {
			await this.refreshEmotesForUser(activeId);
		}

		this.addCommand({
			id: 'cancel-pre-cache',
			name: 'Cancel active pre-cache download',
			checkCallback: (checking: boolean) => {
				const canCancel = this.isPreCaching() &&
					!!this.abortController &&
					!this.abortController.signal.aborted;

				if (checking) {
					return canCancel;
				}

				if (!canCancel) {
					new Notice('No active pre-cache to cancel');
					return false;
				}

				this.cancelPreCache();
				new Notice('Pre-cache cancelled');
				this.logMessage('Pre-cache cancelled via command', 'basic');
				return true;
			}
		});

		this.addSettingTab(new SettingsTab(this.app, this));
		this.logMessage('Plugin loaded successfully', 'basic');
	}

	onunload(): void {
		this.cancelPreCache();
		this.logMessage('Plugin unloaded', 'basic');
	}

	onStateChange(listener: () => void): () => void {
		this.stateListeners.add(listener);
		return () => this.stateListeners.delete(listener);
	}

	getStreamerDisplayMap(): Map<string, string> {
		return new Map(this.settings.builtInStreamers.map((s) => [s.internalKey, s.displayName]));
	}

	getStreamerIdMap(): Map<string, string> {
		return new Map(this.settings.builtInStreamers.map((s) => [s.internalKey, s.twitchId]));
	}

	getActiveTwitchId(): string | null {
		const manualId = this.settings.twitchUserId.trim();
		if (manualId) {
			return manualId;
		}
		if (!this.settings.selectedStreamerId) {
			return null;
		}
		return this.getStreamerIdMap().get(this.settings.selectedStreamerId) ?? null;
	}

	getCacheDir(): string {
		return this.CACHE_DIR;
	}

	getEmoteCount(): number {
		return this.emoteSuggest?.getEmoteCount() ?? 0;
	}

	getEmoteMap(): Map<string, string> {
		return this.emoteSuggest?.getEmoteMap() ?? new Map();
	}

	logMessage(message: string, level: LogLevel = 'basic'): void {
		if (this.logger) {
			this.logger.log(message, level);
			return;
		}
		console.log(`[7TV] ${message}`);
	}

	resetPreCacheStatus(): void {
		this.preCacheComplete = false;
		this.notifyStateChange();
	}

	isPreCacheComplete(): boolean {
		return this.preCacheComplete;
	}

	async refreshEmotesForUser(twitchId: string): Promise<void> {
		this.logMessage(`Fetching emotes for Twitch ID: ${twitchId}`, 'basic');
		const emoteMap = await fetchEmotesForTwitchId(twitchId, this.logger);
		this.emoteSuggest.updateEmoteMap(emoteMap);

		if (emoteMap.size === 0) {
			this.logger.warn(`No emotes found for user ${twitchId}`);
		} else {
			this.logMessage(`Loaded ${emoteMap.size} emotes`, 'basic');
		}

		this.preCacheComplete = false;
		this.notifyStateChange();
	}

	async insertEmoteByStrategy(editor: Editor, name: string, id: string): Promise<void> {
		if (this.settings.cacheStrategy === 'no-cache') {
			const emote = createNoCacheEmoteElement(name, id);
			editor.replaceSelection(emote.outerHTML);
			return;
		}

		await this.insertWithOnDemandCache(editor, name, id);
	}

	async ensureCacheInitialized(): Promise<void> {
		if (this.settings.cacheStrategy === 'no-cache') {
			return;
		}
		await this.initializeCache();
	}

	hasLoadedEmotes(): boolean {
		return this.getEmoteCount() > 0;
	}

	async triggerPreCache(): Promise<void> {
		const emoteMap = this.getEmoteMap();
		if (emoteMap.size === 0) {
			throw new Error('No emotes loaded to cache');
		}

		this.preCacheComplete = false;
		this.abortController = this.createAbortController();
		this.activeDownloadPromise = this.preCacheEmoteSet(emoteMap)
			.then(() => {
				this.preCacheComplete = true;
				this.logMessage('Pre-cache completed', 'basic');
			})
			.catch((error: unknown) => {
				if (error instanceof DOMException && error.name === 'AbortError') {
					this.logMessage('Pre-cache cancelled', 'basic');
					return;
				}
				this.logger.error(`Pre-cache failed: ${error}`);
				throw error;
			})
			.finally(() => {
				this.activeDownloadPromise = null;
				this.notifyStateChange();
			});

		this.notifyStateChange();
	}

	cancelPreCache(): void {
		if (this.abortController && !this.abortController.signal.aborted) {
			this.abortController.abort();
		}
		this.downloadTracker.cancelFromCommand();
		this.activeDownloadPromise = null;
		this.notifyStateChange();
	}

	isPreCaching(): boolean {
		return this.activeDownloadPromise !== null;
	}

	async loadSettings(): Promise<void> {
		const data = await this.loadData();
		this.settings = Object.assign({}, DEFAULT_SETTINGS, data);
		this.settings.builtInStreamers = this.settings.builtInStreamers ?? [];
	}

	async saveSettings(): Promise<void> {
		await this.saveData(this.settings);
		this.notifyStateChange();
	}

	private notifyStateChange(): void {
		for (const listener of this.stateListeners) {
			listener();
		}
	}

	private async loadStreamersFromJson(): Promise<StreamerDefinition[]> {
		try {
			const streamersPath = `${this.manifest.dir}/streamers.json`;
			const exists = await this.app.vault.adapter.exists(streamersPath);
			if (!exists) {
				this.logMessage('streamers.json not found in plugin directory', 'verbose');
				return [];
			}

			const content = await this.app.vault.adapter.read(streamersPath);
			const data = JSON.parse(content);

			if (Array.isArray(data?.streamers)) {
				return data.streamers;
			}
			if (!Array.isArray(data)) {
				return [];
			}

			return data.map((item: any) => ({
				displayName: item.displayName || item[0] || '',
				twitchId: item.twitchId || item[1] || '',
				internalKey: item.internalKey || item[2] || ''
			}));
		} catch (error) {
			this.logger.error(`Failed to load streamers.json: ${error}`);
			return [];
		}
	}

	private createAbortController(): AbortController {
		if (this.abortController) {
			this.abortController.abort();
		}
		this.abortController = new AbortController();
		return this.abortController;
	}

	private async insertWithOnDemandCache(editor: Editor, name: string, id: string): Promise<void> {
		const cacheRelativePath = `${this.CACHE_DIR}/${id}.webp`;
		const cdnUrl = `https://cdn.7tv.app/emote/${id}/1x.webp`;
		const isCached = await this.app.vault.adapter.exists(cacheRelativePath);

		const picture = createOnDemandEmotePicture({
			name,
			cachePath: cacheRelativePath,
			cdnUrl,
			preferCache: isCached
		});
		editor.replaceSelection(picture.outerHTML);

		if (isCached) {
			return;
		}

		const timer = window.setTimeout(() => {
			void this.downloadToCache(id, cdnUrl, cacheRelativePath).catch((error: unknown) => {
				this.logger.warn(`On-demand cache download failed for ${id}: ${error}`);
			});
		}, 500);
		this.register(() => window.clearTimeout(timer));
	}

	private async initializeCache(): Promise<void> {
		try {
			if (await this.app.vault.adapter.exists(this.CACHE_DIR)) {
				return;
			}
			await this.app.vault.createFolder(this.CACHE_DIR);
			this.logMessage(`Cache directory created: ${this.CACHE_DIR}`, 'verbose');
		} catch (error) {
			this.logger.error(`Cache initialization error: ${error}`);
		}
	}

	private async preCacheEmoteSet(emoteMap: Map<string, string>): Promise<void> {
		const emoteIds = Array.from(emoteMap.values());
		const totalEmotes = emoteIds.length;
		const estimatedTotalBytes = totalEmotes * 50 * 1024;
		const batchSize = 3;
		const totalBatches = Math.ceil(totalEmotes / batchSize);

		this.downloadTracker.start(totalEmotes, () => this.cancelPreCache());
		this.downloadTracker.setTotalBytes(estimatedTotalBytes);
		this.notifyStateChange();

		for (let batchIndex = 0; batchIndex < totalBatches; batchIndex++) {
			if (this.abortController?.signal.aborted || this.downloadTracker.isCancelledRequested()) {
				throw new DOMException('Download cancelled', 'AbortError');
			}

			const start = batchIndex * batchSize;
			const end = Math.min(start + batchSize, totalEmotes);
			const batch = emoteIds.slice(start, end);

			this.downloadTracker.updateBatch(batchIndex + 1);
			const tasks = batch.map((id) =>
				this.ensureEmoteCached(id)
					.then((bytes) => this.downloadTracker.recordSuccess(bytes))
					.catch(() => this.downloadTracker.recordFailure())
			);

			await Promise.allSettled(tasks);

			await new Promise<void>((resolve) => {
				const timer = window.setTimeout(resolve, 50);
				this.register(() => window.clearTimeout(timer));
			});
		}

		if (!this.abortController?.signal.aborted && !this.downloadTracker.isCancelledRequested()) {
			this.downloadTracker.complete();
		}
	}

	private async ensureEmoteCached(emoteId: string): Promise<number> {
		const cachePath = `${this.CACHE_DIR}/${emoteId}.webp`;
		if (await this.app.vault.adapter.exists(cachePath)) {
			return 0;
		}

		const cdnUrl = `https://cdn.7tv.app/emote/${emoteId}/1x.webp`;
		return this.downloadToCache(emoteId, cdnUrl, cachePath);
	}

	private async downloadToCache(emoteId: string, sourceUrl: string, destPath: string): Promise<number> {
		const response = await fetch(sourceUrl, {
			signal: this.abortController?.signal
		});
		if (!response.ok) {
			throw new Error(`HTTP ${response.status}`);
		}

		const arrayBuffer = await response.arrayBuffer();
		await this.app.vault.adapter.writeBinary(destPath, arrayBuffer);
		this.logMessage(`Cached emote ${emoteId}`, 'debug');
		return arrayBuffer.byteLength;
	}
}
